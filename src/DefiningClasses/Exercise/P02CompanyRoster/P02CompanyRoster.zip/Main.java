package DefiningClasses.Exercise.P02CompanyRoster;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        Map<String, Department> departments = new HashMap<>();

        for (int i = 0; i < n; i++) {
            String[] employeeData = scanner.nextLine().split("\\s+");
            String name = employeeData[0];
            double salary = Double.parseDouble(employeeData[1]);
            String position = employeeData[2];
            String departmentName = employeeData[3];
            String email = employeeData.length >= 5 ? employeeData[4] : null;
            int age = employeeData.length == 6 ? Integer.parseInt(employeeData[5]) : -1;

            Employee employee = new Employee(name, salary, position, departmentName, email, age);

            departments.putIfAbsent(departmentName, new Department(departmentName));
            departments.get(departmentName).addEmployee(employee);
        }

        Department highestPaidDepartment = departments.values()
                .stream()
                .max(Comparator.comparingDouble(Department::getAverageSalary))
                .orElse(null);

        if (highestPaidDepartment != null) {
            System.out.println("Highest Average Salary: " + highestPaidDepartment.getDepartment());

            highestPaidDepartment.getEmployees()
                    .stream()
                    .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
                    .forEach(System.out::println);
        }

        scanner.close();
    }
}
