package Generics.Exercise.P08CustomListSorter;

public class Main {
    public static void main(String[] args) {
        CommandInterpreter.interpretCommands();
    }
}
